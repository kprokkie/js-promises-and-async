function maxLength (arr, length) {
    return arr.filter((str) => str.length >= length);
}

const strings = ['at', 'cat', 'dog', 'kites', 'tiger'];
console.log(maxLength(strings, 4));
console.log(strings);





