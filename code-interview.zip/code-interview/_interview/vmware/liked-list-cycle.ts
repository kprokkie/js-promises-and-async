var hasCycle = function (head) {

    let curr = head;
    let hash = {};
    while (curr) {
        if (hash[curr.val] === undefined) {
            hash[curr.val] = curr.val;
            curr = curr.next;
        } else return false;
    }
    return false;
};