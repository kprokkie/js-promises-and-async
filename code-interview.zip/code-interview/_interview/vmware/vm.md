LeetCode
Explore
Problems
Mock
Contest
Articles
Discuss
 Store 
New Playground
kprokkie
VMware
Notice
We've improved our algorithm that calculates company tags and their frequencies to be more accurate and current.

This page updates weekly on Saturday.

You can filter the results by different time periods.

You have solved 13 / 59 problems.

Show problem tags
Select time period:
All time	
 	#	Title	Acceptance	Difficulty	Frequency
76	
Minimum Window Substring	32.7%	Hard	
50	
Pow(x, n)	28.9%	Medium	
33	
Search in Rotated Sorted Array	33.4%	Medium	
2	
Add Two Numbers	32.3%	Medium	
39	
Combination Sum	52.1%	Medium	
146	
LRU Cache	28.8%	Medium	
23	
Merge k Sorted Lists	37.2%	Hard	
10	
Regular Expression Matching	26.0%	Hard	
116	
Populating Next Right Pointers in Each Node	40.6%	Medium	
322	
Coin Change	32.7%	Medium	
5	
Longest Palindromic Substring	28.4%	Medium	
237	
Delete Node in a Linked List	56.9%	Easy	
543	
Diameter of Binary Tree	47.9%	Easy	
300	
Longest Increasing Subsequence	41.7%	Medium	
49	
Group Anagrams	51.2%	Medium	
20	
Valid Parentheses	37.7%	Easy	
4	
Median of Two Sorted Arrays	27.9%	Hard	
21	
Merge Two Sorted Lists	50.3%	Easy	
47	
Permutations II	43.3%	Medium	
1	
Two Sum	44.8%	Easy	
148	
Sort List	38.4%	Medium	
215	
Kth Largest Element in an Array	51.2%	Medium	
460	
LFU Cache	31.5%	Hard	
468	
Validate IP Address	21.9%	Medium	
697	
Degree of an Array	52.2%	Easy	
3	
Longest Substring Without Repeating Characters	29.2%	Medium	
46	
Permutations	58.9%	Medium	
62	
Unique Paths	50.3%	Medium	
98	
Validate Binary Search Tree
26.8%	Medium	
206	
Reverse Linked List
58.3%	Easy	
17	
Letter Combinations of a Phone Number	44.0%	Medium	
25	
Reverse Nodes in k-Group	38.8%	Hard	
37	
Sudoku Solver	39.9%	Hard	
56	
Merge Intervals	37.4%	Medium	
72	
Edit Distance	40.4%	Hard	
113	
Path Sum II	43.3%	Medium	
141	
Linked List Cycle	38.9%	Easy	
200	
Number of Islands	44.0%	Medium	
692	
Top K Frequent Words	48.2%	Medium	
234	
Palindrome Linked List	37.5%	Easy	
698	
Partition to K Equal Sum Subsets	44.2%	Medium	
153	
Find Minimum in Rotated Sorted Array	43.9%	Medium	
402	
Remove K Digits	27.3%	Medium	
829	
Consecutive Numbers Sum	35.5%	Hard	
139	
Word Break	37.5%	Medium	
295	
Find Median from Data Stream	40.0%	Hard	
268	
Missing Number	49.7%	Easy	
109	
Convert Sorted List to Binary Search Tree	43.8%	Medium	
221	
Maximal Square	34.8%	Medium	
380	
Insert Delete GetRandom O(1)	44.6%	Medium	
525	
Contiguous Array	44.3%	Medium	
85	
Maximal Rectangle	35.3%	Hard	
88	
Merge Sorted Array	37.5%	Easy	
93	
Restore IP Addresses	33.1%	Medium	
238	
Product of Array Except Self	57.7%	Medium	
102	
Binary Tree Level Order Traversal	51.2%	Medium	
394	
Decode String	47.4%	Medium	
304	
Range Sum Query 2D - Immutable	35.3%	Medium	
1209	
Remove All Adjacent Duplicates in String II	56.5%	Medium	
Copyright © 2019 LeetCodeHelp Center  |  Jobs  |  Bug Bounty  |  Terms  |  Privacy Policy      United States