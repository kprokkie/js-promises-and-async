
// // Complete the palindromeIndex function below.
// function palindromeIndex(s) {


// }

// const a = 'aaab';
// console.log(palindromeIndex(a));

/**
 * @param {string} s
 * @return {boolean}
 */
var canPermutePalindrome = function(s) {
    let hash = {};
    
    for (let char of s) {
        hash[char] = ++hash[char] || 1;
    }

    console.log(hash);

    let count = 0;
    for (let val of Object.values(hash)) {
        count += val % 2;
    }

    return count <=1;
    
};

const str = 'aab';
console.log(canPermutePalindrome(str));