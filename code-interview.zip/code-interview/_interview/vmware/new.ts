// function createMultiply(base) {
//     return (x) =>  base * x;
// }

// var timesSeven = createMultiply(7);

// console.log(timesSeven(10)); // returns 70

// timesSeven(21); // returns 147

function compareStrings(firstString, secondString, thirdString) {
    // Write your code here
    return [firstString, secondString, thirdString].sort().join('');


    // if (firstString < secondString)
    //     resultString += firstString;
    // else 
    //     resultString += secondString;

    // return resultString;

}


console.log(compareStrings('klmno', 'abcde', 'fghij'));
console.log(compareStrings('ab', 'ac', 'aa'));