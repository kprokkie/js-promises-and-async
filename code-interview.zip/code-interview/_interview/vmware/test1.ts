// you can write to stdout for debugging purposes, e.g.
// console.log('this is a debug message');

function solution(S) {
    // write your code in JavaScript
    
    if (!S.length) return -1;
    
    const HELP = '--help';
    const NAME = '--name';
    const COUNT = '--count';
    
    let validName;
    let validCount;
    let validHelp;
    
    let args = S.split(' ');
    
    let i = 0;
    while ( i < args.length) {
        if (args[i] === NAME) {
            if (args[i + 1]) {
                validName = validateName(args[i + 1]);
                i = i + 2;
            }
            else return -1;
        }
        else if (args[i] === COUNT) {
            if (args[i + 1]) {
                validCount = validateCount(args[i + 1]);
                i = i + 2;
            }
            else return -1;
        } else if (args[i] === HELP) {
            validHelp = 1;
            i = i + 1;
        } else return -1;
    }
    
    if (validName === -1 || validCount === -1) return -1;
    else if (validName === 0 && validHelp === 1) return 1;
    else if (validCount === 0 && validHelp === 1) return 1;
    else if (validHelp === 1) return 1;
}

function validateName(val) {
    if (val.length >= 3 && val.length <= 10) return 0;
    else return -1;
}

function validateCount(val) {
    if (val >= 10 && val <= 100) return 0;
    else return -1;
}


