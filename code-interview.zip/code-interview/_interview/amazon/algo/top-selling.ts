// heaps

class Item {
    constructor(name, sale) {
        
    }
}

class TopSellingItem {
    constructor () {
        this.items = [];
    }
}

TopSellingItem.prototype.add = () => {

}