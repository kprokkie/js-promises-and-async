function flattenArray(arr) {
    let res = [];
    while (arr.length) {
        console.log(arr);
        let next = arr.shift();
        console.log(next);
        if (Array.isArray(next))
            arr = next.concat(arr);
        else
            res.push(next);
    }
    return res;
}


const arr = [1, [2, [3]], [4]];
console.log(flattenArray(arr));