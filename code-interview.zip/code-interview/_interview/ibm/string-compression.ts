function compressedString(message) {
    // Write your code here

    if (!message) {
        return message;
    }

    let length;
    // using stack
    let stack = [];
    let compressedMessage = '';
    for (let char of message) {
        if (!stack.length) {
            stack.push(char);
        } else {
            if (stack.includes(char)) {
                stack.push(char);
            } else {
                length = stack.length > 1 ? stack.length.toString() : '';
                compressedMessage += stack.pop() + length.toString();
                stack = []; // clear stack
                stack.push(char);
            }
        }
    }
    // emptying stack after iteration
    length = stack.length > 1 ? stack.length.toString() : '';
    compressedMessage += stack.pop() + length;
    stack = [];

    return compressedMessage;
}




const message = 'abbbbbc';
// const message = null;
console.log(compressedString(message));