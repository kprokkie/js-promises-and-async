// Multiple Pointer Pattern

// [1,1,1,1,2,2,3]
// 3