# Leet Code Solutions

>

>

>

## Want some extra practice? 
```Here are a list of some of the top interview questions focusing on data structures and algorithms:```

> [LC42](https://LC42-Trapping-Rain-Water.kprokkie.repl.run) Trapping Rain Water

> [LC344](https://repl.it/@kprokkie/LC344-Reverse-String) Reverse String   

> [LC412](https://repl.it/@kprokkie/LC412-Fizz-Buzz) Fizz Buzz    

> [LC136](https://repl.it/@kprokkie/LC136-Single-Number) Single Number    

> [LC104](https://repl.it/@kprokkie/LC104-Maximum-Depth-of-Binary-Tree) Maximum Depth of Binary Tree    

> [LC283](https://repl.it/@kprokkie/LC283-Move-Zeroes) Move Zeroes    

> [LC371](https://repl.it/@kprokkie/LC371-Sum-of-Two-Integers) Sum of Two Integers    

> [LC206](https://repl.it/@kprokkie/LC206-Reverse-Linked-List) Reverse Linked List    

> [LC171](https://repl.it/@kprokkie/LC171-Excel-Sheet-Column-Number) Excel Sheet Column Number

> [LC169](https://repl.it/@kprokkie/LC169-Majority-Element) Majority Element

> [LC13](https://repl.it/@kprokkie/LC13-Roman-to-Integer) Roman to Integer

> [LC237](https://repl.it/@kprokkie/LC237-Delete-Node-in-a-Linked-List) Delete Node in a Linked List

> [LC122](https://repl.it/@kprokkie/LC122-Best-Time-to-Buy-and-Sell-Stock-II) Best Time to Buy and Sell Stock II

> [LC242](https://repl.it/@kprokkie/242-Valid-Anagram) Valid Anagram

> [LC217](https://repl.it/@kprokkie/217-Contains-Duplicate) Contains Duplicate

> [LC387](https://repl.it/@kprokkie/LC387-First-Unique-Character-in-a-String) First Unique Character in a String

> [LC268](https://repl.it/@kprokkie/LC268-Missing-Number) Missing Number

> [LC350]() Intersection of Two Arrays II ```PENDING```

> [LC121](https://repl.it/@kprokkie/LC121-Best-Time-to-Buy-and-Sell-Stock) Best Time to Buy and Sell Stock

> [LC21](https://repl.it/@kprokkie/LC21-Merge-Two-Sorted-Lists) Merge Two Sorted Lists

> [LC202](https://repl.it/@kprokkie/LC202-Happy-Number) Happy Number

> [LC118](https://repl.it/@kprokkie/LC118-Pascals-Triangle) Pascals Triangle

> [LC70](https://repl.it/@kprokkie/LC70-Climbing-Stairs) Climbing Stairs

> [LC409](https://repl.it/@kprokkie/LC409-Longest-Palindrome) Longest Palindrome
